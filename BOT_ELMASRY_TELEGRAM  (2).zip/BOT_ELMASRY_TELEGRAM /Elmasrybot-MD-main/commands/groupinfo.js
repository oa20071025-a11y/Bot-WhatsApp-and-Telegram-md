async function groupInfoCommand(sock, chatId, msg) {
    try {
        // Get group metadata
        const groupMetadata = await sock.groupMetadata(chatId);
        
        // Get group profile picture
        let pp;
        try {
            pp = await sock.profilePictureUrl(chatId, 'image');
        } catch {
            pp = 'https://i.imgur.com/2wzGhpF.jpeg'; // Default image
        }

        // Get admins from participants
        const participants = groupMetadata.participants;
        const groupAdmins = participants.filter(p => p.admin);
        const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
        
        // Get group owner
        const owner = groupMetadata.owner || groupAdmins.find(p => p.admin === 'superadmin')?.id || chatId.split('-')[0] + '@s.whatsapp.net';

        // Create info text (تعريب العناوين لتبدو احترافية)
        const text = `
┌──「 *بيانات المجموعة* 」
▢ *♻️ المعرف:*
   • ${groupMetadata.id}
▢ *🔖 الاسم* : 
   • ${groupMetadata.subject}
▢ *👥 الأعضاء* :
   • ${participants.length}
▢ *🤿 مالك المجموعة:*
   • @${owner.split('@')[0]}
▢ *🕵🏻‍♂️ المشرفين:*
${listAdmin}

▢ *📌 الوصف* :
   • ${groupMetadata.desc?.toString() || 'لا يوجد وصف'}
`.trim();

        // Send the message with image, mentions and your WhatsApp Link
        await sock.sendMessage(chatId, {
            image: { url: pp },
            caption: text,
            mentions: [...groupAdmins.map(v => v.id), owner],
            contextInfo: {
                externalAdReply: {
                    title: "تواصل مع المطور",
                    body: "Elmasry Bot Support",
                    thumbnailUrl: pp,
                    sourceUrl: "https://wa.me/201013815156", // رابط رقم تليفونك
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            }
        });

    } catch (error) {
        console.error('Error in groupinfo command:', error);
        await sock.sendMessage(chatId, { text: 'فشل في جلب بيانات المجموعة!' });
    }
}

module.exports = groupInfoCommand;
