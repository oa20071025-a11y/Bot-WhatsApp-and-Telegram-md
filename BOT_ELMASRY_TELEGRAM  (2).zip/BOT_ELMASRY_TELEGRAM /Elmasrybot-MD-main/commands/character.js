const axios = require('axios');

async function characterCommand(sock, chatId, message) {
    let userToAnalyze;
    
    // التحقق من المنشن
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // التحقق من الرد
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToAnalyze) {
        await sock.sendMessage(chatId, { 
            text: 'يا ريت تعمل منشن لشخص أو ترد على رسالته عشان أحلل شخصيته! ✨\n\n🌐 افتح الموقع من هنا:\nhttps://indexhtml-rho-blue.vercel.app/',
            contextInfo: {
                externalAdReply: {
                    title: 'ELMASRY BOT 🌟',
                    body: 'اضغط هنا لزيارة الموقع الرسمي',
                    sourceUrl: 'https://indexhtml-rho-blue.vercel.app/',
                    mediaType: 2,
                    renderLargerThumbnail: true,
                    showAdAttribution: true
                }
            }
        });
        return;
    }

    try {
        // صورة البروفايل
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(userToAnalyze, 'image');
        } catch {
            profilePic = 'https://telegra.ph/file/a8a1c93a02c388d757271.jpg'; 
        }

        const traits = [
            "ذكي", "مبدع", "عنيد", "طموح", "حنون",
            "كاريزما", "واثق من نفسه", "متعاطف", "نشيط", "ودود",
            "كريم", "صادق", "فرفوش", "خيالي", "مستقل",
            "بديهي", "طيب", "منطقي", "مخلص", "متفائل",
            "شغوف", "صبور", "مثابر", "يعتمد عليه", "داهية",
            "متفهم", "حكيم", "اجتماعي", "رايق"
        ];

        const numTraits = Math.floor(Math.random() * 3) + 3; 
        const selectedTraits = [];
        while (selectedTraits.length < numTraits) {
            const randomTrait = traits[Math.floor(Math.random() * traits.length)];
            if (!selectedTraits.includes(randomTrait)) {
                selectedTraits.push(randomTrait);
            }
        }

        const traitPercentages = selectedTraits.map(trait => {
            const percentage = Math.floor(Math.random() * 41) + 60; 
            return `✨ ${trait}: ${percentage}%`;
        });

        const analysis = `🔮 *تحليل الشخصية من إلماصري* 🔮\n\n` +
            `👤 *المستخدم:* @${userToAnalyze.split('@')[0]}\n\n` +
            `📊 *أهم الصفات:*\n${traitPercentages.join('\n')}\n\n` +
            `🎯 *التقييم النهائي:* ${Math.floor(Math.random() * 21) + 80}%\n\n` +
            `⚠️ *ملاحظة:* ده هزار للترفيه بس 😂\n\n` +
            `🌐 افتح الموقع الرسمي من هنا:\nhttps://indexhtml-rho-blue.vercel.app/`;

        await sock.sendMessage(chatId, {
            image: { url: profilePic },
            caption: analysis,
            mentions: [userToAnalyze],
            contextInfo: {
                externalAdReply: {
                    title: 'ELMASRY BOT 🌟',
                    body: 'اضغط هنا لزيارة الموقع الرسمي',
                    sourceUrl: 'https://indexhtml-rho-blue.vercel.app/',
                    mediaType: 2,
                    renderLargerThumbnail: true,
                    showAdAttribution: true
                }
            }
        });

    } catch (error) {
        console.error('Error in character command:', error);
        await sock.sendMessage(chatId, { 
            text: 'للأسف فشلت في تحليل الشخصية ❌\n\n🌐 افتح الموقع من هنا:\nhttps://indexhtml-rho-blue.vercel.app/',
            contextInfo: {
                externalAdReply: {
                    title: 'ELMASRY BOT 🌟',
                    body: 'زيارة الموقع الرسمي',
                    sourceUrl: 'https://indexhtml-rho-blue.vercel.app/',
                    mediaType: 2,
                    renderLargerThumbnail: true,
                    showAdAttribution: true
                }
            }
        });
    }
}

module.exports = characterCommand;