const eightBallResponses = [
    "ايوه جدًا! بس السؤال ده بتاع واحد فاهم... وإنت لأ. 🤦‍♂️",
    "يا عم لأ! هو أنا قاعد فاضي عشان أرد على الأسئلة الساذجة دي؟ 🙄.",
    "ارجع بعدين لما تكون دماغك مش عاملة شاي بلبن. ☕️🧠",
    "الأكيد إنك لو سألت سؤال زي ده تاني هتتطرد. 🚪👋.",
    "الشك بيقول: 'يا خسارة التعليم فيك.' إجابتك غلط طبعًا. 📉🙅‍♀️.",
    "أكيد من غير كلام! الإجابة سهلة جدًا لدرجة إني مستغرب إنك سألت. 🧐🤨.",
    "لأ، وأتمنى إنك تكون فهمت الإهانة اللي في الـ 'لأ' دي. 🖕😎.",
    "في أمل بسيط، بس مش لدرجة إنك تفكر إنك جبت الإجابة صح لوحدك. ✨🤏."
];

async function eightBallCommand(sock, chatId, question) {
    if (!question) {
        await sock.sendMessage(chatId, { text: 'قول يعم ام السؤال 😂✨' });
        return;
    }

    const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];
    await sock.sendMessage(chatId, { text: `🎱 ${randomResponse}` });
}

module.exports = { eightBallCommand };
