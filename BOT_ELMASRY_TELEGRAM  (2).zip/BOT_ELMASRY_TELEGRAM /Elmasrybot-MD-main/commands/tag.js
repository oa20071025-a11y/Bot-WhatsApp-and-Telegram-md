const isAdmin = require('../lib/isAdmin');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

async function downloadMediaMessage(message, mediaType) {
    const stream = await downloadContentFromMessage(message, mediaType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    const filePath = path.join(__dirname, '../temp/', `${Date.now()}.${mediaType}`);
    fs.writeFileSync(filePath, buffer);
    return filePath;
}

async function tagCommand(sock, chatId, senderId, messageText, replyMessage, message) {
    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    // ❌ لو البوت مش أدمن
    if (!isBotAdmin) {
        await sock.sendMessage(chatId, { 
            text: '⚠️ *تـنـبـيـه VIP* ⚠️\n\nيـرجى تـرفـيـع الـبوت لـرتبـة *أدمـن* أولاً لـيتمكن من مـنـاداة الأعـضاء! ⚙️💎' 
        }, { quoted: message });
        return;
    }

    // ❌ لو المستخدم العادي حاول يستخدم التاج
    if (!isSenderAdmin) {
        const stickerPath = './assets/sticktag.webp';  // مسار الملصق
        if (fs.existsSync(stickerPath)) {
            const stickerBuffer = fs.readFileSync(stickerPath);
            await sock.sendMessage(chatId, { sticker: stickerBuffer }, { quoted: message });
        } else {
            // رد احتياطي لو الملصق مش موجود بشكل شيك
            await sock.sendMessage(chatId, { text: '🚫 *عـذراً يا وحـش*.. الـمـنـاداة لـلأدمـن فـقـط! 👑' }, { quoted: message });
        }
        return;
    }

    const groupMetadata = await sock.groupMetadata(chatId);
    const participants = groupMetadata.participants;
    const mentionedJidList = participants.map(p => p.id);

    // زينة لرسالة التاج
    const tagHeader = '📢 *إعـلان مـلـكـي لـلـجـمـيـع* 📢\n━━━━━━━━━━━━━━━━━━━━\n\n';
    const tagFooter = '\n\n━━━━━━━━━━━━━━━━━━━━\n💎 *VIP SYSTEM | مـنـاداة شـامـلـة* 💎';

    if (replyMessage) {
        let messageContent = {};

        // التعامل مع الصور
        if (replyMessage.imageMessage) {
            const filePath = await downloadMediaMessage(replyMessage.imageMessage, 'image');
            messageContent = {
                image: { url: filePath },
                caption: tagHeader + (messageText || replyMessage.imageMessage.caption || 'تـابـعـوا هـذا الـمـنـشـور ✨') + tagFooter,
                mentions: mentionedJidList
            };
        }
        // التعامل مع الفيديوهات
        else if (replyMessage.videoMessage) {
            const filePath = await downloadMediaMessage(replyMessage.videoMessage, 'video');
            messageContent = {
                video: { url: filePath },
                caption: tagHeader + (messageText || replyMessage.videoMessage.caption || 'انـتـبـاه لـلـفـيـديـو يـا وحـوش 🎬') + tagFooter,
                mentions: mentionedJidList
            };
        }
        // التعامل مع الرسائل النصية
        else if (replyMessage.conversation || replyMessage.extendedTextMessage) {
            const originalText = replyMessage.conversation || replyMessage.extendedTextMessage.text;
            messageContent = {
                text: tagHeader + originalText + tagFooter,
                mentions: mentionedJidList
            };
        }
        // التعامل مع الملفات
        else if (replyMessage.documentMessage) {
            const filePath = await downloadMediaMessage(replyMessage.documentMessage, 'document');
            messageContent = {
                document: { url: filePath },
                fileName: replyMessage.documentMessage.fileName,
                caption: tagHeader + (messageText || 'مـلـف هـام لـلـجـمـيـع 📄') + tagFooter,
                mentions: mentionedJidList
            };
        }

        if (Object.keys(messageContent).length > 0) {
            await sock.sendMessage(chatId, messageContent);
        }
    } else {
        // لو مفيش ريبلأي (منشن عادي)
        await sock.sendMessage(chatId, {
            text: tagHeader + (messageText || "تـنـبـيـه لـلجـمـيـع! 🔔") + tagFooter,
            mentions: mentionedJidList
        });
    }
}

module.exports = tagCommand;
