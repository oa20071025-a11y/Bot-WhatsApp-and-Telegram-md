const fs = require('fs');

// قائمة الكلمات العربية
const words = ['برمجة', 'بوت', 'مصر', 'واتساب', 'قهوة', 'هاتف', 'كمبيوتر'];
let hangmanGames = {};

function startHangman(sock, chatId) {
    const word = words[Math.floor(Math.random() * words.length)];
    const maskedWord = '_ '.repeat(word.length).trim();

    hangmanGames[chatId] = {
        word,
        maskedWord: maskedWord.split(' '),
        guessedLetters: [],
        wrongGuesses: 0,
        maxWrongGuesses: 6,
    };

    sock.sendMessage(chatId, { text: `🎮 بدأت اللعبة! الكلمة هي: ${maskedWord}\nأرسل حرفاً لتخمينه.` });
}

function guessLetter(sock, chatId, letter) {
    if (!hangmanGames[chatId]) {
        sock.sendMessage(chatId, { text: '❌ لا توجد لعبة جارية حالياً. ابدأ لعبة جديدة بـ .hangman' });
        return;
    }

    const game = hangmanGames[chatId];
    const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;

    if (guessedLetters.includes(letter)) {
        sock.sendMessage(chatId, { text: `⚠️ لقد اخترت الحرف "${letter}" من قبل. جرب حرفاً آخر.` });
        return;
    }

    guessedLetters.push(letter);

    if (word.includes(letter)) {
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                maskedWord[i] = letter;
            }
        }
        sock.sendMessage(chatId, { text: `✅ تخمين صحيح! الكلمة: ${maskedWord.join(' ')}` });

        if (!maskedWord.includes('_')) {
            sock.sendMessage(chatId, { text: `🥳 مبروك! لقد عرفت الكلمة وهي: ${word}` });
            delete hangmanGames[chatId];
        }
    } else {
        game.wrongGuesses += 1;
        sock.sendMessage(chatId, { text: `❌ تخمين خاطئ! متبقي لك ${maxWrongGuesses - game.wrongGuesses} محاولات.` });

        if (game.wrongGuesses >= maxWrongGuesses) {
            sock.sendMessage(chatId, { text: `💀 حظ أوفر! انتهت اللعبة. الكلمة كانت: ${word}` });
            delete hangmanGames[chatId];
        }
    }
}

module.exports = { startHangman, guessLetter };
