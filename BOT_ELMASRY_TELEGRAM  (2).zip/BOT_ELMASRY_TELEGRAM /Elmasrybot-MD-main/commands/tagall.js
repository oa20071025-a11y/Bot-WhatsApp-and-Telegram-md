const isAdmin = require('../lib/isAdmin');

async function tagAllCommand(sock, chatId, senderId, message) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
        
        // ❌ التحقق من صلاحية البوت
        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ *تـنـبـيـه إداري* ⚠️\n\nيـرجى رفـع الـبوت لـرتبـة *أدمـن* أولاً لـتفعيل خاصية النداء الشامل! ⚙️💎' 
            }, { quoted: message });
            return;
        }

        // ❌ التحقق من صلاحية المرسل
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { 
                text: '🚫 *تـصـريـح مـرفـوض* 🚫\n\nعـذراً يـا وحـش، خـاصـية الـ (TagAll) لـلأساطـير (الأدمـن) فـقـط! 👑' 
            }, { quoted: message });
            return;
        }

        // جلب بيانات المجموعة
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;

        if (!participants || participants.length === 0) {
            await sock.sendMessage(chatId, { text: '❌ *عـذراً*.. لـم أتمكن من العثور على أعضاء في هذه المجموعة!' });
            return;
        }

        // 📢 تجهيز رسالة النداء الملكي
        let messageText = '📢 *نــداء لـلـجـمـيـع يـا وحـوش* 📢\n';
        messageText += '━━━━━━━━━━━━━━━━━━━━\n\n';
        messageText += '💎 *قـائـمـة الأعـضـاء الـ VIP:*\n\n';

        participants.forEach((participant, index) => {
            messageText += `${index + 1}️⃣ ◈ @${participant.id.split('@')[0]}\n`;
        });

        messageText += '\n━━━━━━━━━━━━━━━━━━━━\n';
        messageText += '✨ *بـالـتـوفـيـق لـلـجـمـيـع | VIP BOT* ✨';

        // إرسال الرسالة مع المنشن
        await sock.sendMessage(chatId, {
            text: messageText,
            mentions: participants.map(p => p.id)
        });

    } catch (error) {
        console.error('Error in tagall command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ *فـشـل الـنـداء الـشـامـل*.. حـدث خـطأ تـقـني غـير مـتـوقـع! 🛠️' 
        });
    }
}

module.exports = tagAllCommand;
