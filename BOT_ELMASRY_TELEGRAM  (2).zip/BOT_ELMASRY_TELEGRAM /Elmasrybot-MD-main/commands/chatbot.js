const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

// مسار تخزين البيانات لضمان بقاء الذاكرة
const USER_GROUP_DATA = path.join(__dirname, '../data/userGroupData.json');

/** * تحسين إدارة البيانات والذاكرة الدائمة
 */
function loadUserGroupData() {
    try {
        if (!fs.existsSync(path.dirname(USER_GROUP_DATA))) {
            fs.mkdirSync(path.dirname(USER_GROUP_DATA), { recursive: true });
        }
        if (!fs.existsSync(USER_GROUP_DATA)) {
            fs.writeFileSync(USER_GROUP_DATA, JSON.stringify({ chatbot: {}, memory: {} }));
        }
        return JSON.parse(fs.readFileSync(USER_GROUP_DATA));
    } catch (error) {
        return { chatbot: {}, memory: {} };
    }
}

function saveUserGroupData(data) {
    try {
        fs.writeFileSync(USER_GROUP_DATA, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('❌ فشل في حفظ البيانات:', e);
    }
}

/** * تحديث ذاكرة المستخدم لتجنب الـ undefined
 */
function updateMemory(senderId, text) {
    const data = loadUserGroupData();
    if (!data.memory) data.memory = {};
    
    if (!data.memory[senderId]) {
        data.memory[senderId] = { name: 'يا بطل', history: [] };
    }
    
    const mem = data.memory[senderId];

    if (text.includes('اسمي')) {
        const words = text.split('اسمي')[1].trim().split(' ');
        if (words[0]) mem.name = words[0];
    }
    
    mem.history.push(text);
    if (mem.history.length > 5) mem.history.shift();
    
    data.memory[senderId] = mem;
    saveUserGroupData(data);
    return mem;
}

/** * أوامر التحكم العامة (.chatbot on/off)
 */
async function handleChatbotCommand(sock, chatId, message, match) {
    const data = loadUserGroupData();
    
    if (match === 'on') {
        data.chatbot[chatId] = true;
        saveUserGroupData(data);
        return sock.sendMessage(chatId, { text: '✅ "البرنس" رجع الساحة.. اكتب .elmasry وبعدها سؤالك وهقوم بالواجب!' });
    } else if (match === 'off') {
        delete data.chatbot[chatId];
        saveUserGroupData(data);
        return sock.sendMessage(chatId, { text: '💤 ريحت شوية.. لما تحتاجني فعلني تاني.' });
    }
}

/** * معالجة الردود عند مناداة البوت بـ .elmasry
 */
async function handleChatbotResponse(sock, chatId, message, userMessage, senderId) {
    const data = loadUserGroupData();
    if (!data.chatbot[chatId]) return;

    // الشرط الأساسي الجديد: هل الرسالة بتبدأ بـ .elmasry ؟
    const prefix = ".elmasry";
    if (!userMessage.toLowerCase().startsWith(prefix)) return;

    // استخراج السؤال الفعلي بعد الكلمة المفتاحية
    const actualQuestion = userMessage.slice(prefix.length).trim();
    if (!actualQuestion) return sock.sendMessage(chatId, { text: 'اؤمر يا برنس.. عايز تقول إيه بعد .elmasry ؟' });

    try {
        await sock.sendPresenceUpdate('composing', chatId); // إظهار حالة يكتب الآن
        
        const userMem = updateMemory(senderId, actualQuestion);
        
        // استخدام محرك Blackbox AI الأقوى
        const res = await fetch('https://api.blackbox.ai/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                messages: [{ 
                    role: 'user', 
                    content: `أنت اسمك "البرنس". شخصيتك: مصري، ابن بلد، ساخر، ومضحك. الشخص اللي بيكلمك اسمه ${userMem.name}. رد عليه بلهجة مصرية عامية شعبية قصيرة جداً. رسالته هي: ${actualQuestion}` 
                }],
                model: "deepseek-v3",
                max_tokens: 250
            })
        });

        let responseText = await res.text();
        responseText = responseText.replace(/\$@\$.*?\$@\$/g, '').trim(); // تنظيف الرد

        if (responseText) {
            await sock.sendMessage(chatId, { text: responseText }, { quoted: message });
        }
    } catch (e) {
        await sock.sendMessage(chatId, { text: 'النت مأنتخ معايا يا زميلي.. جرب تاني كمان شوية.' }, { quoted: message });
    }
}

module.exports = { handleChatbotCommand, handleChatbotResponse };
