async function resetlinkCommand(sock, chatId, senderId) {
    // إعدادات الـ VIP والـ Newsletter للتناسق مع باقي البوت
    const vipConfig = { 
        contextInfo: { 
            forwardingScore: 999, 
            isForwarded: true, 
            forwardedNewsletterMessageInfo: { 
                newsletterJid: '120363405610374694@newsletter', 
                newsletterName: '💎 VIP SYSTEM CONTROL', 
                serverMessageId: 1 
            } 
        } 
    };

    try {
        // التحقق من صلاحيات الأدمن
        const groupMetadata = await sock.groupMetadata(chatId);
        const isAdmin = groupMetadata.participants
            .filter(p => p.admin)
            .map(p => p.id)
            .includes(senderId);

        // التحقق من صلاحيات البوت
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
        const isBotAdmin = groupMetadata.participants
            .filter(p => p.admin)
            .map(p => p.id)
            .includes(botId);

        // ❌ لو مش أدمن
        if (!isAdmin) {
            await sock.sendMessage(chatId, { 
                text: '🚫 *تـنـبـيـه إداري* 🚫\n\nعذراً يا وحش، هذا الأمر مخصص فقط لـ *أساطير الإدارة* (Admins) 👑\nلا يمكنك تغيير رابط المملكة! 🛡️',
                ...vipConfig 
            });
            return;
        }

        // ❌ لو البوت مش أدمن
        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { 
                text: '⚠️ *صلاحيات ناقصة* ⚠️\n\nارفع البوت *أدمن* الأول عشان أقدر أتحكم في روابط المجموعة يا غالي! ⚙️💎',
                ...vipConfig 
            });
            return;
        }

        // تنفيذ عملية تغيير الرابط
        const newCode = await sock.groupRevokeInvite(chatId);
        
        // ✅ رسالة النجاح بشكل VIP
        let successMessage = '🔄 *تـم تـغـيـيـر الـرابط بـنـجـاح* 🔄\n';
        successMessage += '━━━━━━━━━━━━━━━━━━━\n\n';
        successMessage += '🛡️ *أمن المجموعة في أمان الآن*\n';
        successMessage += '🔗 *الرابط الجديد الحصري:*\n\n';
        successMessage += `🌐 https://chat.whatsapp.com/${newCode}\n\n`;
        successMessage += '━━━━━━━━━━━━━━━━━━━\n';
        successMessage += '✨ *VIP BOT | نـحـمـي مـمـلـكـتـك بـذكـاء* ✨';

        await sock.sendMessage(chatId, { 
            text: successMessage,
            ...vipConfig 
        });

    } catch (error) {
        console.error('Error in resetlink command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ *فشل في تحديث الرابط*\nبرجاء التأكد من إعدادات المجموعة والمحاولة مرة أخرى! 🛠️',
            ...vipConfig 
        });
    }
}

module.exports = resetlinkCommand;
