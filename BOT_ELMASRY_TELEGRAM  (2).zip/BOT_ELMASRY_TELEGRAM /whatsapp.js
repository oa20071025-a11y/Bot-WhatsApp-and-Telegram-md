const { makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs-extra');
const path = require('path');
const { exec } = require('child_process');

async function startWA(userId, phone) {
  const sessionDir = path.join(__dirname, 'sessions', String(userId));
  await fs.ensureDir(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    logger: P({ level: 'silent' }),
    printQRInTerminal: false
  });

  sock.ev.on('creds.update', saveCreds);

  const code = await sock.requestPairingCode(phone.replace('+',''));

  sock.ev.on('connection.update', ({ connection }) => {
    if (connection === 'open') {
      console.log("✅ تم الربط، جاري تشغيل ElmasryBot-MD...");

      exec(`cd Elmasrybot-MD && node index.js`, (err) => {
        if (err) console.log("❌ خطأ في تشغيل البوت:", err);
      });
    }
  });

  return code;
}

module.exports = { startWA };