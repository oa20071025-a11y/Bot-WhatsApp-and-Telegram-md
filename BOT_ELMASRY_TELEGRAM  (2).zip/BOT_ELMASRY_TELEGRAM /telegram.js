const { Telegraf } = require('telegraf');
const { startWA } = require('./whatsapp');

const bot = new Telegraf("8595696537:AAEZg1gDcu-GqTVMPPYlAPwMMRVGkp4senY");

bot.start(ctx => {
  ctx.reply("👑 أهلاً بيك في بوت ELMASRY 👑\n\n📲 ابعت رقمك مع كود الدولة:\nمثال: +201234567890");
});

bot.on('text', async ctx => {
  const phone = ctx.message.text.trim();

  if (!phone.startsWith('+')) {
    return ctx.reply("❌ الرقم لازم يبدأ بـ + وكود الدولة");
  }

  ctx.reply("⏳ جاري تجهيز كود الربط...");

  try {
    const code = await startWA(ctx.from.id, phone);
    ctx.reply(`🔐 كود الربط بتاعك:\n\n${code}\n\n📲 افتح واتساب > الأجهزة المرتبطة > ربط جهاز`);
  } catch (err) {
    ctx.reply("❌ حصل خطأ، حاول تاني بعد شوية");
  }
});

bot.launch();